import 'package:flutter/material.dart';

class ColorResources{

static const Color whiteColor = Color(0xffFFFFFF);
static const Color lav1Color = Color(0xff7864ff4e);
static const Color lav2Color = Color(0xff7864FF);
static const Color grey1Color = Color(0xff707070);
static const Color grey2Color = Color(0xff00000080);
static const Color grey3Color = Color(0xff999999);
static const Color black1Color = Color(0xff000000);
static const Color black2Color = Color(0xff363636);
static const Color grey4Color = Color(0xffF4F4F4);

}