class Validator{


  static const hrsValidate = r'^(\d|1\d|2[0-3]|24)$';
  static const minValidate = r'^[1-5][0-9]{0,1}|60$';


}