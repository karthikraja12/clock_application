

class ImageResource{
  static const String clock = "assets/png/clock.png";
  static const String alarm = "assets/png/alarm.png";
  static const String stopWatch = "assets/png/stopwatch.png";
  static const String timer = "assets/png/timer.png";
  static const String addIcon = "assets/png/add_icon.png";
  static const String cClock = "assets/png/c_clock.png";
  static const String cAlarm = "assets/png/c_alarm.png";
  static const String cStopWatch = "assets/png/c_stopwatch.png";
  static const String cTimer = "assets/png/c_timer.png";
  static const String playIcon = "assets/png/play_icon.png";



}