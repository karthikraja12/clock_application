class AlarmModule {
  String hrs;
  String mins;
  bool isOn = false;
  List<String> days =[];

  AlarmModule({required this.hrs, required this.mins});
}
